*SpriteSheetScanner

This tool can find all sprites inside a sprite sheet and save selected ones seperate
in choosen folder(s) or create new sheet(s) of them in 32bit PNG format.


1. Copyright and permissions
2. Warranty
3. How-to use
4. Notice to Keyboard shortcuts


1. SpriteSheetScanner belongs to (c) thinkrealtive (M. Brandt) and should not be offered
or uploaded anywhere without permission. But, of course the usage is free.


2. I don't offer any warranty for damages caused by this program.
Also i can not promise, that everything works perfectly.
I have tested all functions so far and they should work, but it is
of course absolutely possible you find a bug. 
If that happens, be free to contact me and describe the bug.
thinkrelative@outlook.de


3. How-to use

Load or drag and drop any sprite sheet image. You can also load an image
or preset file via command line. Just drag and drop on SpriteSheetScanner.exe.
-
Now select any color(s) in the image with the color picker and set it to transparent.
(This is the requirement to find sprites. You don't have to do this, when your image is a PNG
that is transparent anyway) 
If you are crazy enough to use a jpg image file, the color picker will erase the selected color
with a tolerance value, what is adjustable by pressing right mouse key.
-
After this press the scan button (magnifier). And voilà, all sprites ar marked/framed.
If you haven't choose transparent color(s) before, this will automatically done with the color
in the upper right corner pixel.
-
Now you can select/deselect all the sprite you want to extract by use of left mouse button.
You can select more than one by holding the button and move the mouse.
Besides you can move the selection rect by holding right mouse button, too.
This will work also with the erase and the group tools.
-
After this you might erase some sprites completely, or cut a sprite in parts, or you can
create some groups optional and before i forget to mention, you can 'undo' every changes
by pressing [Ctrl] + [Z]. Important: The color picker has an own undo stack. 
-
Finally export the selected sprites.
Optional you can save your (ground)work as preset file.

Thats it!


4. You can see most keyboard shortcut if you hover mouse pointer above the buttons.

Inside the image you can scroll vertical by turning the mouse wheel and if you hold the middle
button, you can scroll the picture section by moving the mouse.

If you Hold [Ctrl] + mouse wheel turning or pressing [S] or [A] will zoom in and back. 
Hold [Ctrl] + middle mouse button will reset to 100% view.
As long as you hold [X] all selection rectangles will be hide.
